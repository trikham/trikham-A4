import { Component } from '@angular/core';
import { trikham } from './trikham';
import {PersonaldataService} from './personaldata.service';
import {food} from './BreLunDin';
import datab from '../assets/data/breakfast.json';
import datal from '../assets/data/lunch.json';
import datad from '../assets/data/dinner.json';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'trikham';
  myinfo: trikham;
  pList: food[] = datab.breakfastitems;
  lList : food[] = datal.lunchitems;
  dList : food[] = datad.dinneritems;

  constructor(private pservice: PersonaldataService){}

    loadMyPersonalData(): void{
      this.myinfo= this.pservice.loadMyData();

    }
    ngOnInit(){this.loadMyPersonalData();}

  }


