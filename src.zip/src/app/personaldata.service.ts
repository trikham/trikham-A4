import { Injectable } from '@angular/core';
import {trikham} from './trikham'

@Injectable({
  providedIn: 'root'
})
export class PersonaldataService {

  loadMyData(): trikham{
    const trikham: trikham =
    {sid: 991546460, sname: "Muskan Trikha", slogname:"trikham", scampus:"Davis",
    assignmenttitle: "trikham-A4"}
    return trikham;

  }
  constructor() { }
}