export class trikham     {
    sid:number;
    sname:string;
    slogname:string;
    scampus:string;
    assignmenttitle:string;

}