export interface food{
    name: string;
    price: string;
    calories: string
}